<?php
	namespace Home\Controller;
	use Think\Controller;
	
	class CatalogController extends Controller
	{
		public function index()
		{
			$this->display();
		}
		public function view()
		{
			$this->display();
		}
	}
?>