<?php
	namespace Admin\Controller;
	use Think\Controller;
	
	class AddBrandController extends Controller
	{
		public function index()
		{
			$this->display();
		}
	}
?>