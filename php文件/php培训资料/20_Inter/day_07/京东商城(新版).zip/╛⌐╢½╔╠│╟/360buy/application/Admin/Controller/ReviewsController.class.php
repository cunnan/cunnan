<?php
	namespace Admin\Controller;
	use Think\Controller;
	
	class ReviewsController extends Controller
	{
		public function index()
		{
			$this->display();
		}
	}
?>