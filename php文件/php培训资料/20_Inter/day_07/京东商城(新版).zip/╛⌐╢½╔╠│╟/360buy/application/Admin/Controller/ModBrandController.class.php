<?php
	namespace Admin\Controller;
	use Think\Controller;
	
	class ModBrandController extends Controller
	{
		public function index()
		{
			$this->display();
		}
		public function update()
		{
			$this->display();
		}
	}
?>