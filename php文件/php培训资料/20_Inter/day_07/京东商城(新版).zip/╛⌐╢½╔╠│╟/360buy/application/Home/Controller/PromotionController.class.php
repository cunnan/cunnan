<?php
	namespace Home\Controller;
	use Think\Controller;
	
	class PromotionController extends Controller
	{
		public function index()
		{
			$this->display();
		}
	}
?>