<?php
	namespace Admin\Controller;
	use Think\Controller;
	
	class ModTypeController extends Controller
	{
		public function index()
		{
			$this->display();
		}
	}
?>