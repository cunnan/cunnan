<?php
	namespace Admin\Controller;
	use Think\Controller;
	
	class AddTypeController extends Controller
	{
		public function index()
		{
			$this->display();
		}
	}
?>