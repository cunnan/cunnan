<?php
	namespace Admin\Controller;
	use Think\Controller;
	
	class AddProductController extends Controller
	{
		public function index()
		{
			$this->display();
		}
	}
?>