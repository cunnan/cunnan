<?php
	namespace Admin\Controller;
	use Think\Controller;
	
	class UserController extends Controller
	{
		public function index()
		{
			$this->display();
		}
		public function update()
		{
			$this->display();
		}
	}
?>