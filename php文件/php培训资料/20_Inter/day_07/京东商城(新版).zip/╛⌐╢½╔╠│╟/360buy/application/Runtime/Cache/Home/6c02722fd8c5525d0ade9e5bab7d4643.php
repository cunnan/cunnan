<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3c.org/TR/1999/REC-html401-19991224/loose.dtd">
<HTML xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <title></title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link href="/360buy/public/themes/jindong/images/d.css" rel="stylesheet" type="text/css" />
    <SCRIPT src="/360buy/public/themes/jindong/images/nav.js" type=text/javascript></SCRIPT>
    <SCRIPT src="/360buy/public/themes/jindong/images/jscook.js" type=text/javascript></SCRIPT>
    <Script language="JavaScript">
    function selectPage(sel)
    {
      sel.form.submit();
    }
    </Script>
  </head>
  <body class="diy_body">
    <TABLE cellSpacing=0 cellPadding=0 width=545 border=0>
    <FORM name=Form1 action="" method=post>
      <input type="hidden" name="mainboard" value="">
      <input type="hidden" name="cpu" value="">
      <TBODY>
        <TR>
          <TD class=text_18 width=120 background=/360buy/public/themes/jindong/images/DIY_XD_36.gif height=41>&nbsp;<font color="#E23F24">已选：CPU</font></TD>
          <TD class=text_12 align=right width=175 background=/360buy/public/themes/jindong/images/DIY_XD_36.gif  height=41>品牌：
            <SELECT class=input_01 id=brand_id style="WIDTH: 130px; height:21px" name=brand_id>
              <OPTION value="0" selected>--请选择--</OPTION>
              <option value="232">AMD</option>
              <option value="235">Intel(英特尔）</option>
            </SELECT>
          </TD>
          <TD align="center" width=170 background=/360buy/public/themes/jindong/images/DIY_XD_36.gif  height=41>&nbsp;&nbsp;关键字：<INPUT class=input_01 id=keyword style="WIDTH: 104px; height:16px" name=keyword></TD>
          <TD width=40 background=/360buy/public/themes/jindong/images/DIY_XD_36.gif  height=41>
            <INPUT type=image height=20 width=35 src="/360buy/public/themes/jindong/images/b11.gif">
          </TD>
        </TR>
      </TBODY>
    </FORM>
    </TABLE>
    <TABLE cellSpacing=0 cellPadding=0 width=545 border=0 bgcolor="#ffffff">
      <TBODY>
        <TR>
          <TD vAlign=top bgcolor="#ffffff">
            <TABLE bgcolor="#FFFBE2" class=table_01 cellSpacing=0 cellPadding=0 border=0>
              <TBODY>
                <TR>
                  <TD class=table_04 align="center" width=110 height=38>商品图片</TD>
                  <TD class=table_04 align="center" width=308 height=38>商品名称</TD>
                  <TD class=table_04 align="center" width=75 height=38>价格</TD>
                  <TD align="center" width=52 height=38>选用</TD>
                </TR>
              </TBODY>
            </TABLE>
            <div style="border-bottom: #C1C1C1 1px solid;">
              <TABLE class=table_001 cellSpacing=0 cellPadding=0 border=0 bgcolor="#ffffff">
                <TBODY>
                  <TR>
                    <TD class=table_05 align="center" width=109>
                      <A title="AMD Athlon II ×2（速龙II双核）240盒装CPU（Socket AM3/2.8GHz/2M二级缓存/45纳米）A-FAN标志产品！45NM2.8高主频！套装更超值！" href="/360buy/index.php/Goods/index" target=_blank>
                        <IMG height=40 src="/360buy/public/images/201001/thumb_img/4731_thumb_G_1262820447214.jpg" width=54 alt="AMD Athlon II ×2（速龙II双核）240盒装CPU（Socket AM3/2.8GHz/2M二级缓存/45纳米）A-FAN标志产品！45NM2.8高主频！套装更超值！" border="0" style="margin:5px 0 5px">
                      </A>
                    </TD>
                    <TD class=table_05 align=left width=308>
                      <SPAN id=span1_4731 style="margin-left:10px">
                        <A title="AMD Athlon II ×2（速龙II双核）240盒装CPU（Socket AM3/2.8GHz/2M二级缓存/45纳米）A-FAN标志产品！45NM2.8高主频！套装更超值！" href="/360buy/index.php/Goods/index" target=_blank>AMD Athlon II ×2（速龙II双核）240盒装CPU（Socket AM3/2.8GHz/2M二级缓存/45纳米）A-FAN标志产品！45NM2.8高主频！套装更超值！</A>
                      </SPAN>
                      <BR>
                      <FONT color=#316ac5></FONT>
                    </TD>
                    <TD class=table_05 align="center" width=75>
                      <SPAN class=￥ id=span2_4731>￥419</SPAN>
                    </TD>
                    <TD align="center" width=52>
                      <A onclick="javascript:onclickimage('M_CPU','4731');" href="javascript:;">
                        <IMG height=22 src="/360buy/public/themes/jindong/images/b14.gif" width=40 border="0">
                      </A>
                    </TD>
                  </TR>
                </TBODY>
              </TABLE>
              <TABLE class=table_001 cellSpacing=0 cellPadding=0 border=0 bgcolor="#ffffff">
                <TBODY>
                  <TR>
                    <TD class=table_05 align="center" width=109>
                      <A title="AMD Athlon II ×2（速龙II双核）240盒装CPU（Socket AM3/2.8GHz/2M二级缓存/45纳米）A-FAN标志产品！45NM2.8高主频！套装更超值！" href="/360buy/index.php/Goods/index" target=_blank>
                        <IMG height=40 src="/360buy/public/images/201001/thumb_img/4731_thumb_G_1262820447214.jpg" width=54 alt="AMD Athlon II ×2（速龙II双核）240盒装CPU（Socket AM3/2.8GHz/2M二级缓存/45纳米）A-FAN标志产品！45NM2.8高主频！套装更超值！" border="0" style="margin:5px 0 5px">
                      </A>
                    </TD>
                    <TD class=table_05 align=left width=308>
                      <SPAN id=span1_4731 style="margin-left:10px">
                        <A title="AMD Athlon II ×2（速龙II双核）240盒装CPU（Socket AM3/2.8GHz/2M二级缓存/45纳米）A-FAN标志产品！45NM2.8高主频！套装更超值！" href="/360buy/index.php/Goods/index" target=_blank>AMD Athlon II ×2（速龙II双核）240盒装CPU（Socket AM3/2.8GHz/2M二级缓存/45纳米）A-FAN标志产品！45NM2.8高主频！套装更超值！</A>
                      </SPAN>
                      <BR>
                      <FONT color=#316ac5></FONT>
                    </TD>
                    <TD class=table_05 align="center" width=75>
                      <SPAN class=￥ id=span2_4731>￥419</SPAN>
                    </TD>
                    <TD align="center" width=52>
                      <A onclick="javascript:onclickimage('M_CPU','4731');" href="javascript:;">
                        <IMG height=22 src="/360buy/public/themes/jindong/images/b14.gif" width=40 border="0">
                      </A>
                    </TD>
                  </TR>
                </TBODY>
              </TABLE>
              <TABLE class=table_001 cellSpacing=0 cellPadding=0 border=0 bgcolor="#ffffff">
                <TBODY>
                  <TR>
                    <TD class=table_05 align="center" width=109>
                      <A title="AMD Athlon II ×2（速龙II双核）240盒装CPU（Socket AM3/2.8GHz/2M二级缓存/45纳米）A-FAN标志产品！45NM2.8高主频！套装更超值！" href="/360buy/index.php/Goods/index" target=_blank>
                        <IMG height=40 src="/360buy/public/images/201001/thumb_img/4731_thumb_G_1262820447214.jpg" width=54 alt="AMD Athlon II ×2（速龙II双核）240盒装CPU（Socket AM3/2.8GHz/2M二级缓存/45纳米）A-FAN标志产品！45NM2.8高主频！套装更超值！" border="0" style="margin:5px 0 5px">
                      </A>
                    </TD>
                    <TD class=table_05 align=left width=308>
                      <SPAN id=span1_4731 style="margin-left:10px">
                        <A title="AMD Athlon II ×2（速龙II双核）240盒装CPU（Socket AM3/2.8GHz/2M二级缓存/45纳米）A-FAN标志产品！45NM2.8高主频！套装更超值！" href="/360buy/index.php/Goods/index" target=_blank>AMD Athlon II ×2（速龙II双核）240盒装CPU（Socket AM3/2.8GHz/2M二级缓存/45纳米）A-FAN标志产品！45NM2.8高主频！套装更超值！</A>
                      </SPAN>
                      <BR>
                      <FONT color=#316ac5></FONT>
                    </TD>
                    <TD class=table_05 align="center" width=75>
                      <SPAN class=￥ id=span2_4731>￥419</SPAN>
                    </TD>
                    <TD align="center" width=52>
                      <A onclick="javascript:onclickimage('M_CPU','4731');" href="javascript:;">
                        <IMG height=22 src="/360buy/public/themes/jindong/images/b14.gif" width=40 border="0">
                      </A>
                    </TD>
                  </TR>
                </TBODY>
              </TABLE>
            </div>
            <TR>
              <TD class=TXT_12 align=right colSpan=5>
                <form name="selectPageForm" action="" method="get">
                  <div id="pager" class="pagebar"></div>
                </form>
              </TD>
            </TR>
            <TR>
              <TD vAlign=top colSpan=5></TD>
            </TR>
          </TBODY>
        </TABLE>
      </body>
</html>