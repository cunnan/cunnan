<?php
	namespace Admin\Controller;
	use Think\Controller;
	
	class OrderController extends Controller
	{
		public function index()
		{
			$this->display();
		}
		public function show()
		{
			$this->display();
		}
		public function details()
		{
			$this->display();
		}
	}
?>