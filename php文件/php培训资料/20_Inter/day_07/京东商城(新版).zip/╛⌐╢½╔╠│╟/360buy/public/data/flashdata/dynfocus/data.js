imgUrl1="/360buy/public/data/afficheimg/20100810asogcl.jpg";
imgtext1="";
imgLink1=escape("http://vip.souho.net/");
imgUrl2="/360buy/public/data/afficheimg/20100810hdhmav.jpg";
imgtext2="";
imgLink2=escape("http://vip.souho.net/");
imgUrl3="/360buy/public/data/afficheimg/20100810wxmbkx.jpg";
imgtext3="";
imgLink3=escape("http://vip.souho.net/");

var pics=imgUrl1+"|"+imgUrl2+"|"+imgUrl3;
var links=imgLink1+"|"+imgLink2+"|"+imgLink3;
var texts=imgtext1+"|"+imgtext2+"|"+imgtext3;