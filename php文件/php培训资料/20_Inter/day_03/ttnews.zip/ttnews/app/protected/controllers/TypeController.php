<?php
	class TypeController extends Controller
	{
		public function init()
		{}
		public function actionIndex($typeId)
		{
			$this->pageTitle = "天天新闻网-新闻分类";
			
			$newsTypes = NewsTypes::model()->findAll();//所有新闻分类
			$newsInfo = NewsArticles::model()->findAll("typeId={$typeId} order by dateandtime desc");//该分类下所有新闻
			//$newsType = NewsTypes::model()->find("typeId={$typeId}");//当前类型的信息
			$newsType = NewsTypes::model()->findByPk($typeId);//当前类型的信息
			
			$data = array(
				"newsTypes"=>$newsTypes,
				"newsInfo"=>$newsInfo,
				"newsType"=>$newsType
			);
			$this->render("index",$data);
		}
	}
?>