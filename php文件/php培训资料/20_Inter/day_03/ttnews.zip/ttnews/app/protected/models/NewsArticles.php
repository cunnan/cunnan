<?php
	class NewsArticles extends CActiveRecord
	{
		public static function model($className=__CLASS__)
		{
			return parent::model($className);
		}
		public function tableName()
		{
			//return "newsArticles";
			return "{{newsArticles}}";
		}
	}
?>