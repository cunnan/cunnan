<?php
	class SearchController extends Controller
	{
		public function init()
		{}
		public function actionIndex()
		{
			$searchType = $_POST["searchType"];
			$keyword = $_POST["keyword"];
			
			$this->pageTitle = "搜索新闻";
			$newsTypes = NewsTypes::model()->findAll();//新闻分类
			$newsInfo = array();
			if($keyword != NULL)
			{
				$newsInfo = NewsArticles::model()->findAll("{$searchType} like '%{$keyword}%'");
			}
			
			$data = array(
				"newsTypes"=>$newsTypes,
				"newsInfo"=>$newsInfo
			);
			$this->render("index",$data);
		}
	}
?>