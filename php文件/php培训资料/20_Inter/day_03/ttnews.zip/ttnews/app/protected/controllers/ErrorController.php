<?php
	class ErrorController extends Controller
	{
		public function init()
		{}
		public function actionIndex()
		{
			$this->pageTitle = "系统错误信息";
			$newsTypes = NewsTypes::model()->findAll();//新闻分类
			$error = Yii::app()->errorHandler->error;
			
			$data = array(
				"newsTypes"=>$newsTypes,
				"errorMsg"=>$error
			);
			
			$this->render("index",$data);
		}
	}
?>