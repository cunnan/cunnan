<?php
	class NewsController extends Controller
	{
		public function init()
		{}
		public function actionIndex($articleId)
		{
			$this->pageTitle = "查看新闻";
			$newsTypes = NewsTypes::model()->findAll();//新闻分类
			
			//当前查看的新闻
			$sql = "select * from newsArticles a,newsTypes b where a.typeId=b.typeId and a.articleId={$articleId}";
			$db = Yii::app()->db;
			$st = $db->createCommand($sql);
			$newsInfo = $st->queryRow();
			//修改当前查看新闻的hints字段
			$arr = array("hints"=>$newsInfo["hints"]+1);
			//$row = NewsArticles::model()->updateAll($arr,"articleId={$articleId}");
			$row = NewsArticles::model()->updateByPk($articleId,$arr);
			
			$reviews = Reviews::model()->findAll("articleId={$articleId}");//当前新闻的所有评论
			
			
			$data = array(
				"newsTypes"=>$newsTypes,
				"newsInfo"=>$newsInfo,
				"reviews"=>$reviews
			);
			$this->render("index",$data);
		}
		public function actionReviews()
		{
			$articleId = $_POST["articleId"];
			$content = $_POST["content"];
			$userName = $_POST["userName"];
			$face = $_POST["face"];
			
			$reviews = new Reviews();
			$reviews->articleId = $articleId;
			$reviews->body = $content;
			$reviews->userName = $userName;
			$reviews->face = $face;
			$row = $reviews->save();
			
			if($row > 0)
			{
				$this->redirect("index.php?r=success/index/act/review/rst/1/articleId/{$articleId}");
			}
			else
			{
				$this->redirect("index.php?r=success/index/act/review/rst/0/articleId/{$articleId}");
			}
		}
	}
?>